package com.example.lazuardy.digicine;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class cariObat extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private CheckBox g1,g2,g3,g4,g5,g6,g7,g8,g9,g10,
            g11,g12,g13,g14,g15,g16,g17,g18,g19,g20,
            g21,g22,g23,g24,g25,g26,g27,g28,g29,g30,
            g31,g32,g33,g34,g35,g36,g37,g38,g39,g40,
            g41,g42,g43,g44,g45,g46,g47,g48,g49,g50,
            g51,g52,g53,g54;
    private String mSpinnerLabel = "";
    private String mSpinnerLabel1="";
    private String usia, alergi;
    EditText editUsia, editAlergi;
    private float min =0;
    private String kode;
    private static final String TAG = cariObat.class.getSimpleName();

    private static List<String> checked = new ArrayList<>();

    private long jumlahAturanTerkini;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cari_obat);





        g1 = (CheckBox) findViewById(R.id.checkBox1);
        g1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g1");
                } else {
                    checked.remove("g1");
                }
            }
        });

        g2 = (CheckBox) findViewById(R.id.checkBox2);
        g2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g2");
                } else {
                    checked.remove("g2");
                }
            }
        });

        g3 = (CheckBox) findViewById(R.id.checkBox3);
        g3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g3");
                } else {
                    checked.remove("g3");
                }
            }
        });

        g4 = (CheckBox) findViewById(R.id.checkBox4);
        g4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g4");
                } else {
                    checked.remove("g4");
                }
            }
        });
        g5 = (CheckBox) findViewById(R.id.checkBox5);
        g5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g5");
                } else {
                    checked.remove("g5");
                }
            }
        });

        g6 = (CheckBox) findViewById(R.id.checkBox6);
        g6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g6");
                } else {
                    checked.remove("g6");
                }
            }
        });
        g7 = (CheckBox) findViewById(R.id.checkBox7);
        g7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g7");
                } else {
                    checked.remove("g7");
                }
            }
        });
        g8 = (CheckBox) findViewById(R.id.checkBox8);
        g8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g8");
                } else {
                    checked.remove("g8");
                }
            }
        });
        g9 = (CheckBox) findViewById(R.id.checkBox9);
        g9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g9");
                } else {
                    checked.remove("g9");
                }
            }
        });
        g10 = (CheckBox) findViewById(R.id.checkBox10);
        g10.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g10");
                } else {
                    checked.remove("g10");
                }
            }
        });

        g11 = (CheckBox) findViewById(R.id.checkBox11);
        g11.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g11");
                } else {
                    checked.remove("g11");
                }
            }
        });
        g12 = (CheckBox) findViewById(R.id.checkBox12);
        g12.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g12");
                } else {
                    checked.remove("g12");
                }
            }
        });
        g13 = (CheckBox) findViewById(R.id.checkBox13);
        g13.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g13");
                } else {
                    checked.remove("g13");
                }
            }
        });
        g14 = (CheckBox) findViewById(R.id.checkBox14);
        g14.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g14");
                } else {
                    checked.remove("g14");
                }
            }
        });
        g15 = (CheckBox) findViewById(R.id.checkBox15);
        g15.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g15");
                } else {
                    checked.remove("g15");
                }
            }
        });

        g16 = (CheckBox) findViewById(R.id.checkBox16);
        g16.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g16");
                } else {
                    checked.remove("g16");
                }
            }
        });
        g17 = (CheckBox) findViewById(R.id.checkBox17);
        g17.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g17");
                } else {
                    checked.remove("g17");
                }
            }
        });
        g18 = (CheckBox) findViewById(R.id.checkBox18);
        g18.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g18");
                } else {
                    checked.remove("g18");
                }
            }
        });
        g19 = (CheckBox) findViewById(R.id.checkBox19);
        g19.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g19");
                } else {
                    checked.remove("g19");
                }
            }
        });
        g20 = (CheckBox) findViewById(R.id.checkBox20);
        g20.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g20");
                } else {
                    checked.remove("g20");
                }
            }
        });

        g21 = (CheckBox) findViewById(R.id.checkBox21);
        g21.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g21");
                } else {
                    checked.remove("g21");
                }
            }
        });
        g22 = (CheckBox) findViewById(R.id.checkBox22);
        g22.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g22");
                } else {
                    checked.remove("g22");
                }
            }
        });
        g23 = (CheckBox) findViewById(R.id.checkBox23);
        g23.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g23");
                } else {
                    checked.remove("g23");
                }
            }
        });
        g24 = (CheckBox) findViewById(R.id.checkBox24);
        g24.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g24");
                } else {
                    checked.remove("g24");
                }
            }
        });
        g25 = (CheckBox) findViewById(R.id.checkBox25);
        g25.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g25");
                } else {
                    checked.remove("g25");
                }
            }
        });

        g26 = (CheckBox) findViewById(R.id.checkBox26);
        g26.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g26");
                } else {
                    checked.remove("g26");
                }
            }
        });
        g27 = (CheckBox) findViewById(R.id.checkBox27);
        g27.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g27");
                } else {
                    checked.remove("g27");
                }
            }
        });
        g28 = (CheckBox) findViewById(R.id.checkBox28);
        g28.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g28");
                } else {
                    checked.remove("g28");
                }
            }
        });
        g29 = (CheckBox) findViewById(R.id.checkBox29);
        g29.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g29");
                } else {
                    checked.remove("g29");
                }
            }
        });
        g30 = (CheckBox) findViewById(R.id.checkBox30);
        g30.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g30");
                } else {
                    checked.remove("g30");
                }
            }
        });

        g31 = (CheckBox) findViewById(R.id.checkBox31);
        g31.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g31");
                } else {
                    checked.remove("g31");
                }
            }
        });
        g32 = (CheckBox) findViewById(R.id.checkBox32);
        g32.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g32");
                } else {
                    checked.remove("g32");
                }
            }
        });
        g33 = (CheckBox) findViewById(R.id.checkBox33);
        g33.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g33");
                } else {
                    checked.remove("g33");
                }
            }
        });
        g34 = (CheckBox) findViewById(R.id.checkBox34);
        g34.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g34");
                } else {
                    checked.remove("g34");
                }
            }
        });
        g35 = (CheckBox) findViewById(R.id.checkBox35);
        g35.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g35");
                } else {
                    checked.remove("g35");
                }
            }
        });

        g36 = (CheckBox) findViewById(R.id.checkBox36);
        g36.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g36");
                } else {
                    checked.remove("g36");
                }
            }
        });
        g37 = (CheckBox) findViewById(R.id.checkBox37);
        g37.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g37");
                } else {
                    checked.remove("g37");
                }
            }
        });
        g38 = (CheckBox) findViewById(R.id.checkBox38);
        g38.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g38");
                } else {
                    checked.remove("g38");
                }
            }
        });
        g39 = (CheckBox) findViewById(R.id.checkBox39);
        g39.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g39");
                } else {
                    checked.remove("g39");
                }
            }
        });
        g40 = (CheckBox) findViewById(R.id.checkBox40);
        g40.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g40");
                } else {
                    checked.remove("g40");
                }
            }
        });

        g41 = (CheckBox) findViewById(R.id.checkBox41);
        g41.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g41");
                } else {
                    checked.remove("g41");
                }
            }
        });
        g42 = (CheckBox) findViewById(R.id.checkBox42);
        g42.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g42");
                } else {
                    checked.remove("g42");
                }
            }
        });
        g43 = (CheckBox) findViewById(R.id.checkBox43);
        g43.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g43");
                } else {
                    checked.remove("g43");
                }
            }
        });
        g44 = (CheckBox) findViewById(R.id.checkBox44);
        g44.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g44");
                } else {
                    checked.remove("g44");
                }
            }
        });
        g45 = (CheckBox) findViewById(R.id.checkBox45);
        g45.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g45");
                } else {
                    checked.remove("g45");
                }
            }
        });

        g46 = (CheckBox) findViewById(R.id.checkBox46);
        g46.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g46");
                } else {
                    checked.remove("g46");
                }
            }
        });
        g47 = (CheckBox) findViewById(R.id.checkBox47);
        g47.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g47");
                } else {
                    checked.remove("g47");
                }
            }
        });
        g48 = (CheckBox) findViewById(R.id.checkBox48);
        g48.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g48");
                } else {
                    checked.remove("g48");
                }
            }
        });
        g49 = (CheckBox) findViewById(R.id.checkBox49);
        g49.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g49");
                } else {
                    checked.remove("g49");
                }
            }
        });
        g50 = (CheckBox) findViewById(R.id.checkBox50);
        g50.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g50");
                } else {
                    checked.remove("g50");
                }
            }
        });

        g51 = (CheckBox) findViewById(R.id.checkBox51);
        g51.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g51");
                } else {
                    checked.remove("g51");
                }
            }
        });
        g52 = (CheckBox) findViewById(R.id.checkBox52);
        g52.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g52");
                } else {
                    checked.remove("g52");
                }
            }
        });
        g53 = (CheckBox) findViewById(R.id.checkBox53);
        g53.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g53");
                } else {
                    checked.remove("g53");
                }
            }
        });
        g54 = (CheckBox) findViewById(R.id.checkBox54);
        g54.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b==true){
                    checked.add("g54");
                } else {
                    checked.remove("g54");
                }
            }
        });

    }

    public void mencariObat(View view) {
//usia
        Spinner spinner = (Spinner) findViewById(R.id.spinnerUsia);
        mSpinnerLabel = spinner.getSelectedItem().toString();
        System.out.println(mSpinnerLabel);


        if (mSpinnerLabel.equals("0 - 5 Tahun")){
            usia="u1";
        } else if (mSpinnerLabel.equals("6 - 11 Tahun")){
            usia="u2";
        }else if (mSpinnerLabel.equals("12 - 25 Tahun")){
            usia="u3";
        } else if (mSpinnerLabel.equals("26 - 45 Tahun")){
            usia="u4";
        } else if (mSpinnerLabel.equals(">45 Tahun")){
            usia="u5";
        }

        //Alergi
        Spinner spinner1 = (Spinner) findViewById(R.id.spinnerAlergi);
        mSpinnerLabel1 = spinner1.getSelectedItem().toString();
        System.out.println(mSpinnerLabel1);

        if (mSpinnerLabel1.equals("Paracetamol")){
            alergi="a1";
        } else if (mSpinnerLabel1.equals("Ibuprofen")){
            alergi="a2";
        }
        System.out.println(usia);
        System.out.println(alergi);
        System.out.println(checked);

        //=========DATABASE===============
        // DatabaseReference db_digicine = FirebaseDatabase.getInstance().getReference();
        final Map<String,Float> hasilKemiripan = new HashMap<>();
        final DatabaseReference db_digicine = FirebaseDatabase.getInstance().getReference().child("aturan"); //ngambil database di firebase
        db_digicine.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot dataAturan : dataSnapshot.getChildren()) { //for each
                    float kemiripan = 0;
                    for (DataSnapshot gejalaKolom : dataAturan.child("gejala").getChildren()) { //gejalanya banyak
                        if (checked.contains(gejalaKolom.getValue().toString())) {
                            kemiripan++; //kalo ada yg mirip, kemiripan + 1
                        }
                    }

                    if(usia.contains(dataAturan.child("usia").getValue().toString())) //mencari dalam usia
                    {
                        kemiripan += 1;
                    }
                    if (alergi.contains(dataAturan.child("alergi").getValue().toString())){ //mencari dalam alergi
                        kemiripan +=1;
                    }

                    float pembagiGejala = Math.max((float) (dataAturan.child("gejala").getChildrenCount()), checked.size()); //perbandingan antara inputan dan basis kasus

                    float hasil_bagi = kemiripan / pembagiGejala;

                    DecimalFormat df = new DecimalFormat("#.##");
                    hasil_bagi = Float.parseFloat(df.format(hasil_bagi));
                    hasilKemiripan.put(dataAturan.getKey(), hasil_bagi);
                }

                for (Map.Entry<String, Float> entry : hasilKemiripan.entrySet()){ //menyimpan nilai satunya key satunya child
                    if (entry.getValue()>min){ //nyari nilai tertinggi dari suatu entry
                        min = entry.getValue();
                        kode = entry.getKey();
                    }
                }
                if (kode != null){
                    System.out.println(kode+" - "+min);
                    diagnosaObat(kode,min,alergi, usia, checked);
                    db_digicine.removeEventListener(this);

                } else{
                    Toast.makeText(cariObat.this, "Aturan tidak ditemukan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(cariObat.this, "Gagal mencari data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        mSpinnerLabel = adapterView.getItemAtPosition(i).toString();
        editUsia.setText(mSpinnerLabel);
    }


    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    private void diagnosaObat(String kode, final float min, final String alergi, final String usia, final List<String> checked){
        final String kode_aturan = kode;
        final int nilai_kemiripan = (int) (min*100);
        System.out.println("NILAI KEMIRIPAN = "+nilai_kemiripan);



        DatabaseReference obat = FirebaseDatabase.getInstance().getReference().child("aturan").child(kode_aturan);
        obat.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                final String obatnya = dataSnapshot.child("obat").getValue().toString();
                System.out.println("OBATNYA : "+obatnya);
                if (nilai_kemiripan>75) {


                    if (obatnya.equals("ob1")) {
                        Intent intent = new Intent(cariObat.this, obat1.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob2")) {
                        Intent intent = new Intent(cariObat.this, obat2.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob3")) {
                        Intent intent = new Intent(cariObat.this, obat3.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob4")) {
                        Intent intent = new Intent(cariObat.this, obat4.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob5")) {
                        Intent intent = new Intent(cariObat.this, obat5.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob6")) {
                        Intent intent = new Intent(cariObat.this, obat6.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob7")) {
                        Intent intent = new Intent(cariObat.this, obat7.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob8")) {
                        Intent intent = new Intent(cariObat.this, obat8.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob9")) {
                        Intent intent = new Intent(cariObat.this, obat9.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob10")) {
                        Intent intent = new Intent(cariObat.this, obat10.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob11")) {
                        Intent intent = new Intent(cariObat.this, obat11.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob12")) {
                        Intent intent = new Intent(cariObat.this, obat12.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob13")) {
                        Intent intent = new Intent(cariObat.this, obat13.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob14")) {
                        Intent intent = new Intent(cariObat.this, obat14.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob15")) {
                        Intent intent = new Intent(cariObat.this, obat15.class);
                        startActivity(intent);
                    } else if (obatnya.equals("ob41")) {
                        Intent intent = new Intent(cariObat.this, obat1.class);
                        startActivity(intent);
                    }
                } else {

                    final DatabaseReference obat = FirebaseDatabase.getInstance().getReference().child("aturan");

                    obat.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            jumlahAturanTerkini = dataSnapshot.getChildrenCount();
                            manggilAturan(jumlahAturanTerkini, alergi, usia, checked, obatnya);
                            obat.removeEventListener(this);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                    Intent intent = new Intent(cariObat.this, obatTidakDapatDitemukan.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void manggilAturan(long jumlahAturanTerkini, String alergi, String usia, List<String> checked, String obatnya) {
        int jumlahhAturan = (int) jumlahAturanTerkini+1;
        String aturann = "aturan"+jumlahhAturan;

        DatabaseReference database = FirebaseDatabase.getInstance().getReference().child("aturan").child(aturann); //mau nyimpen aturan baru

        database.child("alergi").setValue(alergi);
        database.child("usia").setValue(usia);
        database.child("obat").setValue(obatnya);

        int gejalaTambahan = checked.size();

        for (int i=0; i<gejalaTambahan; i++){
            database.child("gejala").child(String.valueOf(i)).setValue(checked.get(i));
        }

    }
}
