package com.example.lazuardy.digicine;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class obat11 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obat11);
    }
}
