package com.example.lazuardy.digicine;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class menuUtama extends AppCompatActivity {
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama);

    }
    public void pindahHalamanBiodata(View view) {
        intent = new Intent(menuUtama.this, biodata.class);
        startActivity(intent);
    }
    public void pindahHalamanInputObat(View view) {
        intent = new Intent(menuUtama.this, inputObat.class);
        startActivity(intent);
    }

    public void pindahHalamanArtikel(View view) {
        intent = new Intent(menuUtama.this, artikel.class);
        startActivity(intent);
    }

    public void pindahHalamanMenuCatatan(View view) {
        intent = new Intent(menuUtama.this, catatan.class);
        startActivity(intent);
    }

    public void pindahMenuCariObat(View view) {
        intent = new Intent(menuUtama.this, cariObat.class);
        startActivity(intent);
    }
}
