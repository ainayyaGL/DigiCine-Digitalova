package com.example.lazuardy.digicine;




import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataHelperBiodata extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "digicine_db";
    private static final int DATABASE_VERSION = 1;
    public DataHelperBiodata(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        String sql = "create table biodata(nik integer primary key, nama text null, tglLahir text null, jk text null, alamat text null);";
        Log.d("Data", "onCreate: " + sql);
        db.execSQL(sql);
        sql = "INSERT INTO biodata (nik, nama, tglLahir, jk, alamat) VALUES ('1', 'Ainayya', '1999-02-22', 'Perempuan','Magelang');";
        db.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
        // TODO Auto-generated method stub

    }

}