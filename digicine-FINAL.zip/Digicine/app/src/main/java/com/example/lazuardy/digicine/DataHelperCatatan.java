package com.example.lazuardy.digicine;




import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataHelperCatatan extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "digicine_db1";
    private static final int DATABASE_VERSION = 1;
    public DataHelperCatatan(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        String sql = "create table catatan(no integer primary key, judul text null, teks text null);";
        Log.d("Data", "onCreate: " + sql);
        db.execSQL(sql);
        sql = "INSERT INTO catatan (no, judul, teks) VALUES ('1', 'Beli obat', 'beli disana ya');";
        db.execSQL(sql);

    }

    @Override
    public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
        // TODO Auto-generated method stub

    }

}