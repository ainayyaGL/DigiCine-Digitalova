package com.example.lazuardy.digicine;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class alarm extends AppCompatActivity {
    EditText text1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);
        text1 = (EditText) findViewById(R.id.editText);
        Button button = (Button)findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar c1 = Calendar.getInstance();
                SimpleDateFormat sdf1 = new SimpleDateFormat("m");

                EditText e1= (EditText)findViewById(R.id.editText);
                String ws;

                ws = e1.getText().toString();
                System.out.println(ws);
                String sub = ws.substring(3,5);
                System.out.println("sub : "+sub);
                int waktuYangDitentukan = Integer.parseInt(sub);
                String ws1 = sdf1.format(c1.getTime());

                int waktuSekarang = Integer.parseInt(ws1);

                int waktu = (waktuYangDitentukan-waktuSekarang)*60;

                Intent intent = new Intent(alarm.this,OurBroadcastReceiver.class);
                PendingIntent pendingIntent = PendingIntent.getBroadcast(alarm.this,23424243, intent, 0);
                AlarmManager alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
                alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()+(waktu*1000), pendingIntent);


                Toast.makeText(alarm.this, "Alarm akan dimulai dalam " + waktu + " detik", Toast.LENGTH_LONG).show();


            }
        });



    }

    public void showTimePicker(View view) {
        DialogFragment newFragment = new TimePickerFragment1();
        newFragment.show(getSupportFragmentManager(),
                getString(R.string.time_picker));
    }
    public void processTimePickerResult(int hourOfDay, int minute) {
        String hour_string = Integer.toString(hourOfDay);
        String minute_string = Integer.toString(minute);

        String timeMessage = (hour_string + ":" + minute_string);
        text1.setText(timeMessage);
    }
}
