package com.example.lazuardy.digicine;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class artikel extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artikel);
    }
    public void LaunchArticle1(View view) {
        Intent intent = new Intent(this, artikel1.class);
        startActivity(intent);
    }

    public void LaunchArticle2(View view) {
        Intent intent = new Intent(this, artikel2.class);
        startActivity(intent);
    }
    public void LaunchArticle3(View view) {
        Intent intent = new Intent(this, artikel3.class);
        startActivity(intent);
    }
}
